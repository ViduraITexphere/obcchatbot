# coding-money-chatbot
## Installation
1. npm install
2. create .env file and add your API key as:
     API_KEY="Paste API Key here"
